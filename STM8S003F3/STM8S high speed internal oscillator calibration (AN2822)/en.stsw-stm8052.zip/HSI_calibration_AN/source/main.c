/**
  ******************************************************************************
  * @file main.c
  * @brief This file contains the firmware main function.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 09/01/2009
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */
	
/* Includes ------------------------------------------------------------------*/

#include "stm8s_lib.h"
#include "hsi_calibration.h"


/**
  * @addtogroup HSI_CALIBRATION
  * @{
  */
  
/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/

/* Evalboard I/Os configuration */

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* ---------------------------------------------------------------------------*/
/**
  * @brief An example of calibration routine
  * @par Parameters:
  * None
  * @retval None
  */

void main(void)
{
	u32 diff; 
	vu16 error_ppm;
	
  // *** CCO pin configuration
	GPIO_Init(GPIOE, GPIO_PIN_0, GPIO_MODE_OUT_PP_LOW_FAST);

	CLK_DeInit();
	
	CLK_SYSCLKConfig(CLK_PRESCALER_HSIDIV1); // Clock divider to HSI/1
	CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1); // Fcpu division factor: /1

	CLK_CCOConfig(CLK_OUTPUT_HSI);

	_asm("rim\n");			// Interupt enabled

	diff = HSICalibration();   // Calibration call

	error_ppm = (diff * 1000l) / (AVERAGED_PERIODS * IDEAL_CNT_VALUE / 1000);  // error calculation in ppm
	
	while (1) ;  // endless loop
}

/**
  * @brief Reports the name of the source file and the source line number where
  * the assert error has occurred.
  * User can add his own implementation to report the file name and line number.
  * ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line)
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
  */
#ifdef FULL_ASSERT
void assert_failed(u8 *file, u16 line)
#else
void assert_failed(void)
#endif
{
  /* Put enter your own code to manage an assert error */
}
/**
  * @}
  */

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
