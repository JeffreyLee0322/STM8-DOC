/**
  ******************************************************************************
  * @file hsi_calibration.c
  * @brief This file contains functions for STM8S HSI calibration
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 09/01/2009
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */
	
/* Includes ------------------------------------------------------------------*/

#include <stdlib.h>
#include <stm8s_lib.h>
#include "hsi_calibration.h"

/**
  * @addtogroup HSI_CALIBRATION
  * @{
  */

/* Private constants definition ----------------------------------------------*/

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/

  u8 measureState = MEASURE_COMPLETED;
	tFourBytes HSIPulsesPerPeriod;
	u16 firstcapture, lastcapture, overflows;

/* Private function prototypes -----------------------------------------------*/
/**
  * @brief function initialize TIM3 Input Capture and interrupt generation system
  * @par Parameters:
  * None
  * @retval None
  */

void InitHSIMeasurement (void)
{
  TIM3_Channel_TypeDef 			cal_Channel 		= TIM3_CHANNEL_1;
  TIM3_ICPolarity_TypeDef 	cal_ICPolarity 	= TIM3_ICPOLARITY_RISING;
  TIM3_ICSelection_TypeDef 	cal_ICSelection = TIM3_ICSELECTION_DIRECTTI;
  TIM3_ICPSC_TypeDef 				cal_ICPrescaler = TIM3_ICPRESCALER;
  u8 												cal_ICFilter 		= 0x03;
  TIM3_ICInit(cal_Channel, cal_ICPolarity, cal_ICSelection, cal_ICPrescaler, cal_ICFilter);

	TIM3_UpdateRequestConfig(TIM3_UPDATESOURCE_REGULAR);  // Update interupt request is sent only when the counter overflow
	TIM3_UpdateDisableConfig(DISABLE);    								// Update Event Enable
}


/**
  * @brief function measure the calibration signal period lenght as a number of HSI pulses
  * @par Parameters:
  * none
  * @retval error code 
  * - MEASURE_COMPLETED
	* - MEASURE_FAILED
	*/

vu8 MeasureHSIPulses(void)
{
	u16 i = 0;
	u32 cnt = 0;
	
	measureState = MEASURE_START;            				// initial condition
	TIM3_ClearITPendingBit(0xFF);													// Clear all pending interupts
	TIM3_ITConfig(TIM3_IT_CC1, ENABLE);										// Capture/Compare 1 Interrupt Enable
	TIM3_ITConfig(TIM3_IT_UPDATE, ENABLE);								// Update Interrupt Enable
	TIM3_Cmd(ENABLE);																			// enable counter
	
  for (cnt=0; cnt<0x2000; cnt++)
	{
		if (measureState == MEASURE_COMPLETED) 				// wait for measurement complete
			break;
		for (i=0; i<0xFF; i++);
	}
	if (cnt >= 0x1FFF) measureState = MEASURE_FAILED;  // if the measurement is not completed befor the loop end the error rais

	HSIPulsesPerPeriod.uInts[0] = overflows;										// store number of overflows in the higher two bytes
	HSIPulsesPerPeriod.uInts[1] = lastcapture;									// store lastcaptured value in the lower two bytes;
	HSIPulsesPerPeriod.uLongs  -= firstcapture;									// decrease the number of HSI pulses by the firstcaptured value 
	return measureState;
}


/**
  * @brief function calibrate the HSI oscillator frequency according to calibration signal applied to TIM3_CC1 pin.
  * @par Parameters:
  * none
  * @retval error code 
  * u32 difference between actual and demanded frequency
	*/

u32 HSICalibration(void)
{
	vs8 trimVal;
	u32 prevDiff, actDiff;

  InitHSIMeasurement();
	
	trimVal = MAX_TRIM_VAL; // start from the lowest frequency
	CLK->HSITRIMR = (CLK->HSITRIMR & ~CLK_HSITRIMR_HSITRIM) | (trimVal & CLK_HSITRIMR_HSITRIM);

	MeasureHSIPulses();
	prevDiff = labs(HSIPulsesPerPeriod.uLongs - IDEAL_CNT_VALUE);  // measure and calculate the difference between actual and ideal value

	while (trimVal > MIN_TRIM_VAL) {
		trimVal--;	// decrement of the calibration register value
		CLK->HSITRIMR = (CLK->HSITRIMR & ~CLK_HSITRIMR_HSITRIM) | (trimVal & CLK_HSITRIMR_HSITRIM);
	  MeasureHSIPulses();
		actDiff = labs(HSIPulsesPerPeriod.uLongs - IDEAL_CNT_VALUE); // measure and calculate the difference between actual and ideal value
		if (actDiff > prevDiff){  // if the new value is bigger than the previous the trimming value is decreased
			trimVal++;							// increment of the calibration register value
			CLK->HSITRIMR = (CLK->HSITRIMR & ~CLK_HSITRIMR_HSITRIM) | (trimVal & CLK_HSITRIMR_HSITRIM); 
			break;
		}
		prevDiff = actDiff;																		// store the difference for comparison
	}
  return (prevDiff);																			// return the difference
}

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/