/**
  ******************************************************************************
  * @file stm8s_it.c
  * @brief This file contains all the interrupt routines.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 09/01/2009
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */
	
/* Includes ------------------------------------------------------------------*/

#include "stm8s_it.h"
#include "hsi_calibration.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

extern u8 measureState;
extern u16 firstcapture, lastcapture, overflows;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/** @addtogroup IT_Functions
  * @{
  */


/**
  * @brief Dummy interrupt routine
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
*/
@near @interrupt void NonHandledInterrupt(void)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  return;
}

/**
  * @brief TRAP interrupt routine
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
*/
@near @interrupt void TRAP_IRQHandler(void)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  return;
}


/**
  * @brief Timer3 Update/Overflow/Break Interruption routine.
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
  */
@near @interrupt void TIM3_UPD_OVF_BRK_IRQHandler (void)
{
 	
	TIM3_ClearITPendingBit(TIM3_IT_UPDATE); // clear all interupt flags
	
	overflows++;  // increase number of overflows which has to be counted

	return;

}

/**
  * @brief Timer3 Capture/Compare Interruption routine.
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
  */
@near @interrupt @svlreg void TIM3_CAP_COM_IRQHandler (void)
{
	if ( TIM3_GetFlagStatus(TIM3_FLAG_CC1) == SET ) {
		switch (measureState){
			
			case MEASURE_START:
				firstcapture = TIM3_GetCapture1();
				measureState = MEASURE_INPROGRESS;
				overflows = 0x00;
				break;
			
			case MEASURE_INPROGRESS:
				lastcapture = TIM3_GetCapture1();
				measureState = MEASURE_COMPLETED;
				TIM3_ITConfig(TIM3_IT_CC1, DISABLE);   			// disable Timer1 Capture/Compare Interrupt
				TIM3_Cmd(DISABLE);													// stop counter;
				break;
			
			default:
				TIM3_ITConfig(TIM3_IT_CC1, DISABLE);   			// disable Timer1 Capture/Compare Interrupt
				TIM3_Cmd(DISABLE);													// stop counter;
				measureState = MEASURE_FAILED;
				break;
		}
	}
	else {
		measureState = MEASURE_FAILED;
	}
		
		TIM3_ClearITPendingBit(TIM3_IT_CC1);
		
	return;

}


/**
  * @}
  */

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/