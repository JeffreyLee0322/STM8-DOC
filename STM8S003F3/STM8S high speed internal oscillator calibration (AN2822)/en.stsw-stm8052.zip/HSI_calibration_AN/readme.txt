This package contains demonstration firmware for STM8S High Speed Internall oscillator calibration

HW configuration:

5V square reference signal with frequency of 50Hz has to be applied to PD2 (TIM3_CC1, pin 43, LQFP80)
HSI calibrated signal can be observed on PE0 (CLK_CCO, pin 70, LQFP80)

More details can be found in the AN 2822.