/**
  ******************************************************************************
  * @file hsi_calibration.h
  * @brief This file contains all user and system definition of STM8S HSI calibration firmware.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.0
  * @date 09/01/2009
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __HSI_CALIBRATION
#define __HSI_CALIBRATION

/* Exported types ------------------------------------------------------------*/
typedef union
{
   u8			uBytes[4];
   u16		uInts[2];
   u32		uLongs;
} tFourBytes;

/* Exported constants --------------------------------------------------------*/

#define HSI_FREQ						((u32)16000000)
#define CALIBR_FREQ					((u8) 50)

#define MAX_TRIM_VAL	((s8)  3)
#define MIN_TRIM_VAL  ((s8) -4)

#define AVERAGED_PERIODS  8

// ------------- private constants -------------------------

#define MEASURE_START			 	((u8) 0x01)
#define MEASURE_INPROGRESS  ((u8) 0x02)
#define MEASURE_COMPLETED 	((u8) 0x00)
#define MEASURE_FAILED   		((u8) 0xFF)

// ------------- private macros definition -----------------

#if   AVERAGED_PERIODS == 1
	 #define TIM3_ICPRESCALER TIM3_ICPSC_DIV1
	
#elif AVERAGED_PERIODS == 2
	 #define TIM3_ICPRESCALER TIM3_ICPSC_DIV2
	
#elif AVERAGED_PERIODS == 4
	 #define TIM3_ICPRESCALER TIM3_ICPSC_DIV4
	 
#elif AVERAGED_PERIODS == 8
	 #define TIM3_ICPRESCALER TIM3_ICPSC_DIV8
#endif 

#define IDEAL_CNT_VALUE     ((u32) (HSI_FREQ * AVERAGED_PERIODS / CALIBR_FREQ))

/* Exported functions ------------------------------------------------------- */

u32 HSICalibration(void);

#endif /* __HSI_CALIBRATION */

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/