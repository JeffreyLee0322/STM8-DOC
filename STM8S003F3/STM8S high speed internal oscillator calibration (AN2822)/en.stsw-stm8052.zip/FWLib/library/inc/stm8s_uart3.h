/**
  ********************************************************************************
  * @file stm8s_uart3.h
  * @brief This file contains all functions prototypes and macros for the UART3 peripheral.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.0.1
  * @date 09/22/2008
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2008 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM8S_UART3_H
#define __STM8S_UART3_H

/* Includes ------------------------------------------------------------------*/
#include "stm8s_map.h"

/* Exported types ------------------------------------------------------------*/

/** @addtogroup UART3_Exported_Types
  * @{
  */

/**
  * @brief UART3 WakeUP Modes
  */
typedef enum { UART3_WAKEUP_IDLELINE      = (u8)0x00,  /**< 0x01 Idle Line wake up*/
               UART3_WAKEUP_ADDRESSMARK   = (u8)0x08   /**< 0x02 Address Mark wake up*/
             } UART3_WakeUp_TypeDef;

/**
  * @brief UART3 LIN Break detection length possible values
  */
typedef enum { UART3_LINBREAKDETECTIONLENGTH_10BITS = (u8)0x00, /**< 10 bits Lin Break detection            */
               UART3_LINBREAKDETECTIONLENGTH_11BITS = (u8)0x01  /**< 11 bits Lin Break detection          */
             } UART3_LINBreakDetectionLength_TypeDef;


/**
  * @brief UART3 stop bits possible values
  */
typedef enum { UART3_STOPBITS_1  = (u8)0x00,  /**< One stop bit is  transmitted at the end of frame*/
               UART3_STOPBITS_2  = (u8)0x20   /**< Two stop bits are  transmitted at the end of frame*/
             } UART3_StopBits_TypeDef;

/**
  * @brief UART3 parity possible values
  */
typedef enum { UART3_PARITY_NO    = (u8)0x00,    /**< No Parity*/
               UART3_PARITY_EVEN  = (u8)0x04,    /**< Even Parity*/
               UART3_PARITY_ODD   = (u8)0x06     /**< Odd Parity*/
             } UART3_Parity_TypeDef;

/**
  * @brief UART3 Word length possible values
  */
typedef enum { UART3_WORDLENGTH_8D = (u8)0x00,    /**< 0x00 8 bits Data*/
               UART3_WORDLENGTH_9D = (u8)0x10     /**< 0x10 9 bits Data*/
             } UART3_WordLength_TypeDef;

/**
  * @brief UART3 Mode Transmit/Receive possible values
  */
typedef enum { UART3_MODE_RX_ENABLE    = (u8)0x08,  /**< 0x08 Receive Enable*/
               UART3_MODE_TX_ENABLE    = (u8)0x04,  /**< 0x04 Transmit Enable*/
               UART3_MODE_TX_DISABLE   = (u8)0x80,  /**< 0x80 Receive Enable*/
               UART3_MODE_RX_DISABLE   = (u8)0x40,  /**< 0x40 Single-wire Half-duplex mode*/
               UART3_MODE_TXRX_ENABLE  = (u8)0x0C   /**< 0x0C Receive Enable and Transmit enable*/
             } UART3_Mode_TypeDef;

/**
  * @brief UART3 Mode possible values
  */
typedef enum { UART3_LIN_MODE_MASTER  = (u8)0x00, /**<  LIN Master Mode*/
               UART3_LIN_MODE_SLAVE   = (u8)0x01  /**<  LIN Slave Mode*/
             } UART3_LinMode_TypeDef;
/**
  * @brief UART3 automatic resynchronisation possible values
  */
typedef enum { UART3_LIN_AUTOSYNC_DISABLE   = (u8)0x00,  /**< LIN Autosynchronization Disable*/
               UART3_LIN_AUTOSYNC_ENABLE    = (u8)0x01   /**< LIN Autosynchronization Enable*/
             } UART3_LinAutosync_TypeDef;
/**
  * @brief UART3 Divider Update Method possible values
  */
typedef enum { UART3_LIN_DIVUP_LBRR1    = (u8)0x00, /**<  LIN LDIV is updated as soon as LBRR1 is written*/
               UART3_LIN_DIVUP_NEXTRXNE = (u8)0x01  /**<  LIN LDIV is updated at the next received character*/
             } UART3_LinDivUp_TypeDef;


/**
  * @brief UART3 Flag possible values
  */
typedef enum
{
  UART3_FLAG_TXE         = (u16)0x0080, /*!< Transmit Data Register Empty flag */
  UART3_FLAG_TC          = (u16)0x0040, /*!< Transmission Complete flag */
  UART3_FLAG_RXNE        = (u16)0x0020, /*!< Read Data Register Not Empty flag */
  UART3_FLAG_IDLE        = (u16)0x0010, /*!< Idle line detected flag */
  UART3_FLAG_OR_LHE      = (u16)0x0008, /*!< OverRun error flag */
  UART3_FLAG_NF          = (u16)0x0004, /*!< Noise error flag */
  UART3_FLAG_FE          = (u16)0x0002, /*!< Framing Error flag */
  UART3_FLAG_PE          = (u16)0x0001, /*!< Parity Error flag */
  UART3_FLAG_SBK         = (u16)0x0101,  /**< Send Break Complete interrupt flag */
  UART3_FLAG_LBDF        = (u16)0x0210, /**< LIN Break Detection Flag           */
  UART3_FLAG_LHDF        = (u16)0x0302, /**< LIN Header Detection Flag*/
  UART3_FLAG_LSF         = (u16)0x0301  /**< LIN Sync Field Flag*/
} UART3_Flag_TypeDef;

/**
  * @brief UART3_IT possible values
  * Elements values convention: 0xZYX
  * X: Position of the corresponding Interrupt
  * Y: Pending Bit position
  * Z: Register index
  */
typedef enum { UART3_IT_TXE        = (u16)0x0277, /**< Transmit interrupt */
               UART3_IT_TC         = (u16)0x0266, /**< Transmission Complete interrupt */
               UART3_IT_RXNE       = (u16)0x0255, /**< Data Register Not Empty interrupt */
               UART3_IT_IDLE       = (u16)0x0244, /**< Idle line detected interrupt */
               UART3_IT_OR         = (u16)0x0235, /**< OverRun error interrupt */
               UART3_IT_PE         = (u16)0x0100, /**< Parity Error interrupt */
               UART3_IT_LBDF       = (u16)0x0346, /**< LIN Break Detection interrupt */
               UART3_IT_LHDF       = (u16)0x0412, /**< LIN Header Detection interrupt*/
               UART3_IT_RXNE_OR    = (u16)0x0205  /*!< Receive/Overrun interrupt */
             } UART3_IT_TypeDef;


/**
  * @}
  */

/* Exported constants --------------------------------------------------------*/
/* Exported macros ------------------------------------------------------------*/

/* Private macros ------------------------------------------------------------*/

/** @addtogroup UART3_Private_Macros
  * @{
  */

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the FLAGs
  */
#define IS_UART3_FLAG_OK(Flag) \
  (((Flag) == UART3_FLAG_TXE) || \
   ((Flag) == UART3_FLAG_TC)  || \
   ((Flag) == UART3_FLAG_RXNE) || \
   ((Flag) == UART3_FLAG_IDLE) || \
   ((Flag) == UART3_FLAG_OR_LHE) || \
   ((Flag) == UART3_FLAG_NF) || \
   ((Flag) == UART3_FLAG_FE) || \
   ((Flag) == UART3_FLAG_PE) || \
   ((Flag) == UART3_FLAG_SBK) || \
   ((Flag) == UART3_FLAG_LSF) || \
   ((Flag) == UART3_FLAG_LHDF) || \
   ((Flag) == UART3_FLAG_LBDF))


/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the FLAGs that can be cleared by writing 0
  */
#define IS_UART3_CLEAR_FLAG_OK(Flag) \
  (((Flag) == UART3_FLAG_RXNE) || \
   ((Flag) == UART3_FLAG_LHDF) || \
   ((Flag) == UART3_FLAG_LSF) || \
   ((Flag) == UART3_FLAG_LBDF))

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the Interrupts
  */

#define IS_UART3_CONFIG_IT_OK(Interrupt) \
  (((Interrupt) == UART3_IT_PE) || \
   ((Interrupt) == UART3_IT_TXE) || \
   ((Interrupt) == UART3_IT_TC) || \
   ((Interrupt) == UART3_IT_RXNE_OR ) || \
   ((Interrupt) == UART3_IT_IDLE) || \
   ((Interrupt) == UART3_IT_LHDF) || \
   ((Interrupt) == UART3_IT_LBDF))

/**
  * @brief Macro used by the assert function in order to check the different sensitivity values for the pending bit
  */
#define IS_UART3_GET_IT_OK(ITPendingBit) \
  (((ITPendingBit) == UART3_IT_TXE)  || \
   ((ITPendingBit) == UART3_IT_TC)   || \
   ((ITPendingBit) == UART3_IT_RXNE) || \
   ((ITPendingBit) == UART3_IT_IDLE) || \
   ((ITPendingBit) == UART3_IT_OR)  || \
   ((ITPendingBit) == UART3_IT_LBDF)  || \
   ((ITPendingBit) == UART3_IT_LHDF)  || \
   ((ITPendingBit) == UART3_IT_PE))

/**
  * @brief Macro used by the assert function in order to check the different sensitivity values for the pending bit that can be cleared by writing 0
  */
#define IS_UART3_CLEAR_IT_OK(ITPendingBit) \
  (((ITPendingBit) == UART3_IT_RXNE) || \
   ((ITPendingBit) == UART3_IT_LHDF) || \
   ((ITPendingBit) == UART3_IT_LBDF))

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the MODEs
 */
#define IS_UART3_MODE_OK(Mode) \
  (((Mode) == (u8)UART3_MODE_RX_ENABLE) || \
   ((Mode) == (u8)UART3_MODE_RX_DISABLE) || \
   ((Mode) == (u8)UART3_MODE_TX_ENABLE) || \
   ((Mode) == (u8)UART3_MODE_TX_DISABLE) || \
   ((Mode) == (u8)UART3_MODE_TXRX_ENABLE) || \
   ((Mode) == (u8)((u8)UART3_MODE_TX_ENABLE|(u8)UART3_MODE_RX_ENABLE)) || \
   ((Mode) == (u8)((u8)UART3_MODE_TX_ENABLE|(u8)UART3_MODE_RX_DISABLE)) || \
   ((Mode) == (u8)((u8)UART3_MODE_TX_DISABLE|(u8)UART3_MODE_RX_DISABLE)) || \
   ((Mode) == (u8)((u8)UART3_MODE_TX_DISABLE|(u8)UART3_MODE_RX_ENABLE)))

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the WordLengths
 */
#define IS_UART3_WORDLENGTH_OK(WordLength) \
  (((WordLength) == UART3_WORDLENGTH_8D) || \
   ((WordLength) == UART3_WORDLENGTH_9D))


/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the WakeUps
  */
#define IS_UART3_WAKEUP_OK(WakeUpMode) \
  (((WakeUpMode) == UART3_WAKEUP_IDLELINE) || \
   ((WakeUpMode) == UART3_WAKEUP_ADDRESSMARK))

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the LINBreakDetectionLengths
  */
#define IS_UART3_LINBREAKDETECTIONLENGTH_OK(LINBreakDetectionLengths) \
  (((LINBreakDetectionLengths) == UART3_LINBREAKDETECTIONLENGTH_10BITS) || \
   ((LINBreakDetectionLengths) == UART3_LINBREAKDETECTIONLENGTH_11BITS))

/**
  * @brief Macro used by the assert_param function in order to check the different sensitivity values for the UART3_StopBits
  */
#define IS_UART3_STOPBITS_OK(StopBit) \
  (((StopBit) == UART3_STOPBITS_1) || \
   ((StopBit) == UART3_STOPBITS_2))

/**
 * @brief Macro used by the assert_param function in order to check the different sensitivity values for the Paritys
 */
#define IS_UART3_PARITY_OK(Parity) \
  (((Parity) == UART3_PARITY_NO) || \
   ((Parity) == UART3_PARITY_EVEN) || \
   ((Parity) == UART3_PARITY_ODD ))

/**
 * @brief Macro used by the assert_param function in order to check the maximum baudrate value
 */
#define IS_UART3_BAUDRATE_OK(NUM) ((NUM) <= (u32)625000)

/**
 * @brief Macro used by the assert_param function in order to check the address of the UART3 or UART node
 */
#define UART3_ADDRESS_MAX ((u8)16)
#define IS_UART3_ADDRESS_OK(Node) ((Node) < UART3_ADDRESS_MAX)

/**
 * @brief Macro used by the assert_param function in order to check the LIN mode
 */
#define IS_UART3_SLAVE_OK(Mode) \
  (((Mode) == UART3_LIN_MODE_MASTER) || \
   ((Mode) == UART3_LIN_MODE_SLAVE))

/**
 * @brief Macro used by the assert_param function in order to check the LIN automatic resynchronization mode
 */
#define IS_UART3_AUTOSYNC_OK(AutosyncMode) \
  (((AutosyncMode) ==  UART3_LIN_AUTOSYNC_ENABLE) || \
   ((AutosyncMode) == UART3_LIN_AUTOSYNC_DISABLE))

/**
 * @brief Macro used by the assert_param function in order to check the LIN divider update method
 */
#define IS_UART3_DIVUP_OK(DivupMethode) \
  (((DivupMethode) == UART3_LIN_DIVUP_LBRR1) || \
   ((DivupMethode) == UART3_LIN_DIVUP_NEXTRXNE))

/**
  * @}
  */

/* Exported functions ------------------------------------------------------- */

/** @addtogroup UART3_Exported_Functions
  * @{
  */

void UART3_DeInit(void);
void UART3_Init(u32 BaudRate, UART3_WordLength_TypeDef WordLength, UART3_StopBits_TypeDef StopBits, UART3_Parity_TypeDef Parity, UART3_Mode_TypeDef Mode);
void UART3_Cmd(FunctionalState NewState);
void UART3_ITConfig(UART3_IT_TypeDef UART3_IT, FunctionalState NewState);
void UART3_LINBreakDetectionConfig(UART3_LINBreakDetectionLength_TypeDef UART3_LINBreakDetectionLength);
void UART3_LINConfig(UART3_LinMode_TypeDef UART3_Mode, UART3_LinAutosync_TypeDef UART3_Autosync, UART3_LinDivUp_TypeDef UART3_DivUp);
void UART3_LINCmd(FunctionalState NewState);
void UART3_ReceiverWakeUpCmd(FunctionalState NewState);
void UART3_WakeUpConfig( UART3_WakeUp_TypeDef UART3_WakeUp);
u8 UART3_ReceiveData8(void);
u16 UART3_ReceiveData9(void);
void UART3_SendData8(u8 Data);
void UART3_SendData9(u16 Data);
void UART3_SendBreak(void);
void UART3_SetAddress(u8 UART3_Address);

FlagStatus UART3_GetFlagStatus(UART3_Flag_TypeDef UART3_FLAG);
void UART3_ClearFlag(UART3_Flag_TypeDef UART3_FLAG);
ITStatus UART3_GetITStatus(UART3_IT_TypeDef UART3_IT);
void UART3_ClearITPendingBit(UART3_IT_TypeDef UART3_IT);
/**
  * @}
  */

#endif /* __STM8S_UART3_H */

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
